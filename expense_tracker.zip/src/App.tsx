import './App.css';
import { Box, Modal, Button } from '@mui/material'
import { TextInput } from './_components';
import LabTabs from './_components/navbar/navbar';
import { Route, Routes } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
function App() {
  const getvalue = () => {






    return ['sdf', 'sdfd']
  }
  const [modal, setmodal] = useState(false)
  useEffect(() => {
    let arr = []
    arr = getvalue()
console.log(localStorage.getItem('sd'))
    return () => {

    }
  }, [localStorage.getItem('sd')])


  return (
    <Box sx={{ color: 'red', padding: '10px' }} >
      <LabTabs />
      <Routes>
        <Route path='/' element={<h1>root</h1>} />
        <Route path='/transactions' element={<h1>transactions</h1>} />
        <Route path='/manage' element={<h1>manage</h1>} />
      </Routes>
      <TextInput label='hii' />
      <TextInput label='hii' inputType="password" />
      <Button onClick={()=>{localStorage.setItem('sd',"12")}} variant="text">Text</Button>

      <Modal
        open={modal}
      >
        <h1>d</h1>
      </Modal>
      <ChildModal />
    </Box>
  );
}

export default App;


function ChildModal() {
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <React.Fragment>
      <Button onClick={handleOpen}>Open Child Modal</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="child-modal-title"
        aria-describedby="child-modal-description"
      >
        <Box sx={{ width: 200, background: "white" }}>
          <h2 id="child-modal-title">Text in a child modal</h2>
          <p id="child-modal-description">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          </p>
          <Button onClick={handleClose}>Close Child Modal</Button>
          <ChildModal />
        </Box>
      </Modal>
    </React.Fragment>
  );
}